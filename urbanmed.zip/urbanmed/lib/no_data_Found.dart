import 'package:flutter/material.dart';

class NoDataFoundWidget extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('No Data Found'),
    );
  }
}
